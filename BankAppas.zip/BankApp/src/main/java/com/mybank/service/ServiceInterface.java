package com.mybank.service;

import java.util.List;

import com.mybank.bean.BankAppBeanClass;
import com.mybank.exception.BankException;

public interface ServiceInterface {

	public void createAccount(BankAppBeanClass bankDetails) throws BankException;

	public List<BankAppBeanClass> viewAccounts() throws BankException;

	public BankAppBeanClass getDetailsById(int accountNumber) throws BankException;

	public BankAppBeanClass showBalance(int accountNumber) throws BankException;

	public int withdraw(int accountNumber, int amount) throws BankException;

	public int deposit(int accountNumber, int amount) throws BankException;

	public boolean fundTransfer(int sender, int receiver, int amount) throws BankException;

	public List<BankAppBeanClass> getTransactions() throws BankException;
	public BankAppBeanClass getDetailsByUsername(String username) throws BankException;
}
