package com.mybank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mybank.bean.BankAppBeanClass;
import com.mybank.exception.BankException;
import com.mybank.service.ServiceInterface;
@CrossOrigin("http://localhost:4200")
@RestController
public class BankAppController {
	@Autowired
	ServiceInterface serviceObject;

	@RequestMapping("/view")
	public List<BankAppBeanClass> viewAllAccounts() throws BankException {
		return serviceObject.viewAccounts();
	}

	@RequestMapping("/bank/getDetails/{username}")
	public BankAppBeanClass getDetailsByUsername(@PathVariable String username) throws BankException {
		return serviceObject.getDetailsByUsername(username);
	}

	@PostMapping("/bank")
	public void createNewAccount(@RequestBody BankAppBeanClass bankDetails) throws BankException {
		serviceObject.createAccount(bankDetails);
	}

	@GetMapping("/mybank/getmybalance/{accountNumber}")
	public BankAppBeanClass showBalance(@PathVariable int accountNumber) throws BankException {
		return serviceObject.showBalance(accountNumber);
	}

	@PutMapping("/bank/deposit/{accountNumber}/{amount}")
	public int depositMoney(@PathVariable int accountNumber, @PathVariable int amount) throws BankException {
		return serviceObject.deposit(accountNumber, amount);
	}

	@PutMapping("/bank/withdraw/{accountNumber}/{amount}")
	public int withdrawMoney(@PathVariable int accountNumber, @PathVariable int amount) throws BankException {
		return serviceObject.withdraw(accountNumber, amount);
	}

	@PutMapping("/bank/fundtransfer/{sender}/{receiver}/{amount}")
	public boolean fundTransfer(@PathVariable int sender, @PathVariable int receiver, @PathVariable int amount)
			throws BankException {
		return serviceObject.fundTransfer(sender, receiver, amount);
	}

	@GetMapping("/bank/{username}")
	public BankAppBeanClass getDetailsByUserName(@PathVariable("userName") String username) throws BankException {
		return serviceObject.getDetailsByUsername(username);
	}
	@ExceptionHandler({ BankException.class })
	public ResponseEntity<String> errorHandler(Exception exception) {
		return new ResponseEntity<String>("An Error Occured" + exception.getMessage(), HttpStatus.OK);

	}
}
