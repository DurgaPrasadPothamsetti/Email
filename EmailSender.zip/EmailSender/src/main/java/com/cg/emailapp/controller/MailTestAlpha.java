package com.cg.emailapp.controller;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.emailapp.bean.MailData;

@RestController
public class MailTestAlpha {
	@Autowired
	public JavaMailSender javaMailSender;
	
	@GetMapping("/sendMail")
	public String sendMail() {
		SimpleMailMessage message= new SimpleMailMessage();
		message.setTo("manoj.vankayala@gmail.com");
		message.setSubject("Alpha Test PLP Capstore");
		message.setText("Hai This is a Alpha Test!! I Repeat this is a alpha test");
		javaMailSender.send(message);
		
		return "Test Mail Sent Successfully";
	}
	@PostMapping("/sendMail1")
	public String sendMail1(@RequestBody MailData mail) {
		SimpleMailMessage message= new SimpleMailMessage();
		message.setTo(mail.getTo());
		message.setSubject(mail.getSubject());
		message.setText(mail.getBody());
		javaMailSender.send(message);
		
		return "Test Mail Sent Successfully";
	}
	public String sendEmailAttachment(@RequestBody MailData mail) throws MessagingException {
		
		MimeMessage message=javaMailSender.createMimeMessage();
		MimeMessageHelper helper=new MimeMessageHelper(message, true);
		helper.setTo(mail.getTo());
		helper.setSubject(mail.getSubject());
		
		helper.setText(mail.getBody(), true);
		javaMailSender.send(message);
		return "Test Mail Sent Successfully";
	}
}
